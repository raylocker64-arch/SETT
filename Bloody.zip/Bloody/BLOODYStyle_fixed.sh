#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════
#  BLOODYStyle v1.0 — All-in-one Android Tweaker
#  Termux + Shizuku (rish)  ·  Android 10+ (fitur penuh di Android 12+)
#
#  Jalankan :  bash BLOODYStyle.sh
#  CLI      :  --basic  --max  --custom  --reset  --info
#              --reso <persen|reset>  --debug  --no-color  --help
# ══════════════════════════════════════════════════════════════════

# ═══ 1. BOOTSTRAP ═════════════════════════════════════════════════
if [ -z "${BASH_VERSION:-}" ]; then
  command -v bash >/dev/null 2>&1 && exec bash "$0" "$@"
  echo "BLOODYStyle butuh bash. Di Termux: pkg install bash"; exit 1
fi

VER="1.1"
export PATH="$PATH:/system/bin:/system/xbin"
: "${HOME:=/data/data/com.termux/files/home}"
: "${PREFIX:=/data/data/com.termux/files/usr}"
CONF_DIR="$HOME/.bloodystyle"
CONF="$CONF_DIR/config"
BACKUP="$CONF_DIR/backup"
mkdir -p "$CONF_DIR" 2>/dev/null
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)"
trap 'printf "\033[0m\n"; exit 130' INT

DEBUG=0; NONINT=0; ACTION=menu; REASO=""
MODE=""; RISH_BIN=""; PRIV_UID=""; RISH_ERR=""
SIZE_PHYS=""; SIZE_OVR=""; DPI_PHYS=""; DPI_OVR=""
SDK=0; REL="?"; BRAND=""; MODEL="?"; HZ_MAX=60; VULKAN=0; PKGS=""; GAME_PKGS=""
BATCH=""; ON=""; STEP_I=0; STEP_N=0
PW=0; PH=0; PD=0; NW=0; NH=0; ND=0

# ═══ 2. DEFAULT & KONFIG ══════════════════════════════════════════
DEFAULT_KILL="com.facebook.katana com.facebook.orca com.facebook.lite com.instagram.android com.whatsapp com.tencent.mm com.twitter.android com.google.android.youtube com.zhiliaoapp.musically com.ss.android.ugc.trill com.google.android.apps.photos com.android.chrome com.google.android.apps.maps com.spotify.music com.android.calendar com.android.email com.android.contacts"

ANIM=0.2                # skala animasi: 0 / 0.1 / 0.2 / 0.3 / 0.5 / 1
GFX_RENDERER=skiagl     # skiagl | skiavk | default (jangan sentuh)
HZ_MODE=auto            # auto (maks layar) | manual | skip
HZ_MANUAL=120
GAME_FPS=auto           # auto | none | 30 | 45 | 60 | 90 | 120
GAME_DOWNSCALE=none     # none | 0.9 | 0.8 | 0.7 | 0.6 | 0.5
AOT_MODE=speed           # speed | speed-profile | everything-profile
DNS_MODE=keep           # keep | auto | off | cloudflare | google | adguard | quad9
BG_LIMIT=8              # batas cached process
CONFIRM_SECS=15         # timer konfirmasi ubah resolusi (0 = tanpa konfirmasi)
EXTRA_PKGS=""           # paket game tambahan (pisah spasi)
KILL_LIST="$DEFAULT_KILL"
ALL_MODS="touch anim gfx hz game power thermal mem net clean aot disp bloat root"
PROFILE_BASIC=" touch anim gfx hz game power mem "
PROFILE_MAX=" touch anim gfx hz game power thermal mem net clean aot disp bloat root "
CUSTOM_ON="$PROFILE_BASIC"
LAST_APPLY=""

BLOAT_LIST="
com.miui.analytics com.xiaomi.joyose com.miui.powerkeeper com.miui.daemon
com.xiaomi.mipicks com.miui.msa.global com.miui.systemAdSolution com.miui.cloudbackup
com.miui.cleanmaster com.miui.bugreport com.miui.hybrid
com.coloros.oppoguardelf com.coloros.helpme com.coloros.phonemanager com.oppo.marketplacesdk
com.vivo.pushclient com.vivo.appstore
com.samsung.android.game.gos com.samsung.android.bixby com.samsung.android.bixby.agent
com.samsung.android.bixbyvision.framework com.samsung.android.app.tips
com.facebook.services com.facebook.appmanager com.facebook.system
com.google.android.tts com.google.android.marvin.talkback com.google.android.apps.tachyon
com.google.android.videos com.google.android.music
"

# nilai bawaan Android (dipakai Reset kalau backup belum ada)
FALLBACK="
global:window_animation_scale=1.0
global:transition_animation_scale=1.0
global:animator_duration_scale=1.0
global:disable_window_blurs=null
system:pointer_speed=0
system:high_touch_sensitivity_enabled=null
secure:long_press_timeout=null
secure:multi_press_timeout=null
system:peak_refresh_rate=null
system:min_refresh_rate=null
system:user_refresh_rate=null
global:low_power=0
global:low_power_trigger_level=null
global:adaptive_battery_management_enabled=1
global:app_standby_enabled=1
global:forced_app_standby_enabled=null
global:automatic_power_save_mode=null
global:dynamic_power_savings_enabled=null
global:activity_manager_constants=null
global:settings_enable_monitor_phantom_procs=true
global:wifi_scan_always_enabled=null
global:ble_scan_always_enabled=null
global:wifi_networks_available_notification_on=1
global:network_recommendations_enabled=null
global:private_dns_mode=opportunistic
global:private_dns_specifier=null
global:game_driver_opt_in_apps=null
global:updatable_driver_production_opt_in_apps=null
system:screen_brightness_mode=1
"

san() { printf '%s' "$*" | tr -cd 'A-Za-z0-9._ -'; }

SAVE_VARS="ANIM GFX_RENDERER HZ_MODE HZ_MANUAL GAME_FPS GAME_DOWNSCALE AOT_MODE DNS_MODE BG_LIMIT CONFIRM_SECS EXTRA_PKGS KILL_LIST CUSTOM_ON LAST_APPLY"

save_conf() {
  local v
  { for v in $SAVE_VARS; do printf '%s=%q\n' "$v" "${!v}"; done; } > "$CONF" 2>/dev/null
}

load_conf() {
  [ -f "$CONF" ] && . "$CONF" 2>/dev/null
  EXTRA_PKGS=$(san "$EXTRA_PKGS"); KILL_LIST=$(san "$KILL_LIST")
  [ -z "$KILL_LIST" ] && KILL_LIST="$DEFAULT_KILL"
  [[ "$HZ_MANUAL" =~ ^[0-9]+$ ]]          || HZ_MANUAL=120
  [ "$HZ_MANUAL" -ge 30 ] 2>/dev/null && [ "$HZ_MANUAL" -le 240 ] 2>/dev/null || HZ_MANUAL=120
  [[ "$BG_LIMIT" =~ ^[0-9]+$ ]]           || BG_LIMIT=8
  [[ "$CONFIRM_SECS" =~ ^[0-9]+$ ]]       || CONFIRM_SECS=15
  [[ "$ANIM" =~ ^[0-9]+(\.[0-9]+)?$ ]]    || ANIM=0.2
  case "$GFX_RENDERER" in skiagl|skiavk|default) ;; *) GFX_RENDERER=skiagl ;; esac
  case "$HZ_MODE" in auto|manual|skip) ;; *) HZ_MODE=auto ;; esac
  case "$GAME_FPS" in auto|none|30|45|60|90|120) ;; *) GAME_FPS=auto ;; esac
  case "$GAME_DOWNSCALE" in none|0.9|0.8|0.7|0.6|0.5) ;; *) GAME_DOWNSCALE=none ;; esac
  case "$AOT_MODE" in speed|speed-profile|everything-profile) ;; *) AOT_MODE=speed ;; esac
  case "$DNS_MODE" in keep|auto|off|cloudflare|google|adguard|quad9) ;; *) DNS_MODE=keep ;; esac
  CUSTOM_ON=$(san "$CUSTOM_ON"); CUSTOM_ON=" $CUSTOM_ON "
}

# ═══ 3. UI ════════════════════════════════════════════════════════
setup_colors() {
  if [ -t 1 ] && [ -z "${NO_COLOR:-}" ]; then
    RS=$'\033[0m'; DM=$'\033[2m'
    RD=$'\033[1;31m'; GR=$'\033[1;32m'; YL=$'\033[1;33m'; CY=$'\033[1;36m'; WH=$'\033[1;37m'
  else
    RS=; DM=; RD=; GR=; YL=; CY=; WH=
  fi
}

ok()  { printf '  %s✓%s %s\n' "$GR" "$RS" "$*"; }
bad() { printf '  %s✗%s %s\n' "$RD" "$RS" "$*"; }
inf() { printf '  %s•%s %s\n' "$CY" "$RS" "$*"; }
wrn() { printf '  %s!%s %s\n' "$YL" "$RS" "$*"; }
dim() { printf '  %s%s%s\n' "$DM" "$*" "$RS"; }
hdr() { printf '\n  %s▌%s %s%s%s\n\n' "$RD" "$RS" "$WH" "$*" "$RS"; }
eol() { if [ -t 1 ]; then printf '\r\033[K'; else printf '\n'; fi; }
clr() { [ -t 1 ] && printf '\033[2J\033[H'; }

banner() {
  clr
  printf '\n%s' "$RD"
  printf '  ╔╗ ╦  ╔═╗╔═╗╔╦╗╦ ╦ %s╔═╗╔╦╗╦ ╦╦  ╔═╗%s\n' "$WH" "$RD"
  printf '  ╠╩╗║  ║ ║║ ║ ║║╚╦╝ %s╚═╗ ║ ╚╦╝║  ║╣ %s\n' "$WH" "$RD"
  printf '  ╚═╝╩═╝╚═╝╚═╝═╩╝ ╩  %s╚═╝ ╩  ╩ ╩═╝╚═╝%s\n' "$WH" "$RS"
  printf '  %sAll-in-one Tweaker v%s · Termux + Shizuku%s\n' "$DM" "$VER" "$RS"
}

banner_small() { clr; printf '\n  %sBLOODY%sStyle%s %sv%s%s\n' "$RD" "$WH" "$RS" "$DM" "$VER" "$RS"; }

pause() { [ "$NONINT" = 1 ] && return 0; printf '\n  %sENTER untuk lanjut…%s' "$DM" "$RS"; read -r _ || exit 0; }

# ask "teks" [default] → cetak jawaban; return 1 kalau input habis (EOF)
ask() {
  local a
  printf '  %s%s%s ' "$CY" "$1" "$RS" >&2
  read -r a || { printf '\n' >&2; return 1; }
  printf '%s' "${a:-${2:-}}"
}

# choose "prompt" opsi... → cetak opsi terpilih; return 1 kalau batal/salah
choose() {
  local prompt="$1" i=1 o a; shift
  for o in "$@"; do printf '   %s%d)%s %s\n' "$WH" "$i" "$RS" "$o" >&2; i=$((i+1)); done
  a=$(ask "$prompt") || return 1
  if [[ "$a" =~ ^[0-9]+$ ]] && [ "$a" -ge 1 ] && [ "$a" -le "$#" ]; then
    printf '%s' "${!a}"; return 0
  fi
  return 1
}

spin_wait() {  # spin_wait PID "pesan"
  local pid="$1" msg="$2" i=0 fr=(⠋ ⠙ ⠹ ⠸ ⠼ ⠴ ⠦ ⠧ ⠇ ⠏)
  while kill -0 "$pid" 2>/dev/null; do
    [ -t 1 ] && printf '\r  %s%s%s %s' "$YL" "${fr[i%10]}" "$RS" "$msg"
    i=$((i+1)); sleep 0.1
  done
  wait "$pid" 2>/dev/null
}

# ═══ 4. AKSES PRIVILEGE (Shizuku / rish) ══════════════════════════
run_to() { local t="$1"; shift; if command -v timeout >/dev/null 2>&1; then timeout "$t" "$@"; else "$@"; fi; }

find_rish() {
  local c
  for c in "$(command -v rish 2>/dev/null)" "$PREFIX/bin/rish" "$HOME/rish" "$HOME/bin/rish" "$SELF_DIR/rish" "./rish"; do
    [ -n "$c" ] && [ -f "$c" ] && { RISH_BIN="$c"; return 0; }
  done
  return 1
}

prep_rish() {
  local d app
  app=$(printf '%s' "$PREFIX" | sed -n 's#^/data/data/\([^/]*\)/.*#\1#p')
  : "${RISH_APPLICATION_ID:=${app:-com.termux}}"
  export RISH_APPLICATION_ID
  d=$(dirname "$RISH_BIN")
  [ -x "$RISH_BIN" ] || chmod 755 "$RISH_BIN" 2>/dev/null
  [ -f "$d/rish_shizuku.dex" ] && chmod 400 "$d/rish_shizuku.dex" 2>/dev/null
}

# sx "perintah" → jalankan di shell berprivilege (shell uid 2000 / root)
sx() {
  case "$MODE" in
    direct) run_to "${SX_TO:-120}" sh -c "$1" </dev/null ;;
    rish)   run_to "${SX_TO:-120}" "$RISH_BIN" -c "$1" </dev/null ;;
    su)     run_to "${SX_TO:-120}" su -c "$1" </dev/null ;;
    *)      return 127 ;;
  esac
}

probe_priv() {
  local out u
  u=$(id -u 2>/dev/null)
  if [ "$u" = 2000 ] || [ "$u" = 0 ]; then MODE=direct; PRIV_UID="$u"; return 0; fi
  if find_rish; then
    prep_rish
    out=$(run_to 30 "$RISH_BIN" -c id </dev/null 2>&1)
    case "$out" in
      *uid=2000*) MODE=rish; PRIV_UID=2000; return 0 ;;
      *uid=0*)    MODE=rish; PRIV_UID=0;    return 0 ;;
    esac
    RISH_ERR="$out"
  fi
  if command -v su >/dev/null 2>&1; then
    out=$(run_to 15 su -c id </dev/null 2>&1)
    case "$out" in *uid=0*) MODE=su; PRIV_UID=0; return 0 ;; esac
  fi
  return 1
}

shizuku_help() {
  hdr "Shizuku / rish belum siap"
  if [ -z "$RISH_BIN" ]; then dim "file rish belum ditemukan"
  elif [ -n "$RISH_ERR" ]; then dim "rish bilang:"; printf '%s\n' "$RISH_ERR" | head -4 | sed 's/^/    /'; fi
  cat <<'EOF'

  Langkah cepat:
   1. Buka app Shizuku → pastikan "running"
      (Android 11+: Wireless debugging → Start)
   2. Shizuku → "Use Shizuku in terminal apps"
      → pilih Termux → Export (rish + rish_shizuku.dex)
   3. Di Termux: termux-setup-storage
      lalu jalankan skrip ini lagi → setup otomatis
   4. Kalau muncul popup izin Shizuku → Allow
EOF
}

setup_rish() {
  local d src="" dest="$PREFIX/bin"
  hdr "Setup rish otomatis"
  for d in "$SELF_DIR" "$HOME" "$HOME/storage/shared" "$HOME/storage/downloads" /sdcard /sdcard/Download /sdcard/Downloads /sdcard/Documents; do
    [ -f "$d/rish" ] && [ -f "$d/rish_shizuku.dex" ] && { src="$d"; break; }
  done
  if [ -z "$src" ] && [ -d /sdcard ]; then
    d=$(find /sdcard -maxdepth 3 -name rish_shizuku.dex 2>/dev/null | head -1)
    [ -n "$d" ] && [ -f "$(dirname "$d")/rish" ] && src=$(dirname "$d")
  fi
  if [ -z "$src" ]; then
    bad "rish & rish_shizuku.dex belum ketemu"
    dim "export dulu dari app Shizuku, lalu: termux-setup-storage"
    return 1
  fi
  inf "Ketemu di $src"
  mkdir -p "$dest"; rm -f "$dest/rish" "$dest/rish_shizuku.dex"
  cp "$src/rish" "$src/rish_shizuku.dex" "$dest/" || { bad "Gagal menyalin"; return 1; }
  chmod 755 "$dest/rish"; chmod 400 "$dest/rish_shizuku.dex"
  ok "rish terpasang di $dest"
}

# ═══ 5. ENGINE BATCH + BACKUP ═════════════════════════════════════
# Perintah dikumpulkan lalu dikirim SATU KALI per modul (rish lambat kalau per-baris).
PRO='bk() { echo "BK|$1:$2=$(settings get "$1" "$2" 2>/dev/null)"; }
bkn() { echo "BK|meta:$1=$2"; }'

q()  { BATCH+="$*"$'\n'; }
qs() {
  if [ "$DEBUG" = 1 ]; then local t="${*//\'/}"; q "echo '+ $t'"; q "$*"
  else q "$* >/dev/null 2>&1"; fi
}
# sp ns key value → simpan nilai awal ke backup, lalu set
sp() { q "bk $1 $2"; q "settings put $1 $2 $3 >/dev/null 2>&1"; }

keep_backup() {
  local line k
  while IFS= read -r line; do
    case "$line" in BK\|*) ;; *) continue ;; esac
    line="${line#BK|}"; k="${line%%=*}"
    grep -q "^${k}=" "$BACKUP" 2>/dev/null || printf '%s\n' "$line" >> "$BACKUP"
  done <<< "$1"
}

flush() {
  local b="$BATCH" out
  BATCH=""
  [ -z "$b" ] && return 0
  out=$(sx "$PRO
$b" 2>&1)
  keep_backup "$out"
  [ "$DEBUG" = 1 ] && printf '%s\n' "$out" | grep -v '^BK|' | sed 's/^/    /'
  return 0
}

step_head() { STEP_I=$((STEP_I+1)); printf '  %s[%d/%d]%s %s' "$DM" "$STEP_I" "$STEP_N" "$RS" "$1"; }
step_ok()   { eol; printf '  %s✓%s %s[%d/%d]%s %s\n' "$GR" "$RS" "$DM" "$STEP_I" "$STEP_N" "$RS" "$1"; }

step() {  # step "judul" fungsi_modul
  BATCH=""
  "$2"
  step_head "$1"
  flush
  step_ok "$1"
}

# ═══ 6. INFO PERANGKAT ════════════════════════════════════════════
PROBE_DISPLAY='
echo "SIZE_PHYS=$(wm size 2>/dev/null | sed -n "s/^Physical size: *//p")"
echo "SIZE_OVR=$(wm size 2>/dev/null | sed -n "s/^Override size: *//p")"
echo "DPI_PHYS=$(wm density 2>/dev/null | sed -n "s/^Physical density: *//p")"
echo "DPI_OVR=$(wm density 2>/dev/null | sed -n "s/^Override density: *//p")"
'
PROBE_FULL='
echo "SDK=$(getprop ro.build.version.sdk)"
echo "REL=$(getprop ro.build.version.release)"
echo "BRAND=$(getprop ro.product.brand)"
echo "MODEL=$(getprop ro.product.model)"
HZV=$(dumpsys display 2>/dev/null | grep -o "fps=[0-9.]*" | sed "s/fps=//" | sort -n | tail -1)
[ -z "$HZV" ] && HZV=$(dumpsys display 2>/dev/null | grep -o "renderFrameRate=[0-9.]*" | sed "s/renderFrameRate=//" | sort -n | tail -1)
[ -z "$HZV" ] && HZV=$(dumpsys SurfaceFlinger 2>/dev/null | grep -o "refresh-rate *: *[0-9.]*" | grep -o "[0-9.]*$" | sort -n | tail -1)
echo "HZ=$HZV"
echo "VULKAN=$(pm list features 2>/dev/null | grep -c "android.hardware.vulkan.version")"
echo "PKGS=$(pm list packages 2>/dev/null | sed "s/^package://" | tr "\n" " ")"
'

parse_kv() {
  local k v
  while IFS='=' read -r k v; do
    case "$k" in
      SIZE_PHYS) SIZE_PHYS="$v" ;;  SIZE_OVR) SIZE_OVR="$v" ;;
      DPI_PHYS)  DPI_PHYS="$v" ;;   DPI_OVR)  DPI_OVR="$v" ;;
      SDK)       SDK="${v:-0}" ;;   REL)      REL="$v" ;;
      BRAND)     BRAND=$(printf '%s' "$v" | tr '[:upper:]' '[:lower:]') ;;
      MODEL)     MODEL="$v" ;;
      HZ)        HZ_MAX=$(printf '%s' "$v" | awk '{printf "%d", $1+0.5}') ;;
      VULKAN)    VULKAN="${v:-0}" ;;
      PKGS)      PKGS=" $v " ;;
    esac
  done <<< "$1"
}

read_display() { parse_kv "$(SX_TO=40 sx "$PROBE_DISPLAY" 2>/dev/null)"; }

gather_info() {
  parse_kv "$(SX_TO=60 sx "$PROBE_DISPLAY$PROBE_FULL" 2>/dev/null)"
  [[ "$SDK" =~ ^[0-9]+$ ]]     || SDK=0
  [[ "$VULKAN" =~ ^[0-9]+$ ]]  || VULKAN=0
  [[ "$HZ_MAX" =~ ^[0-9]+$ ]]  || HZ_MAX=60
  [ "$HZ_MAX" -ge 30 ] || HZ_MAX=60
}

detect_games() {
  local p; GAME_PKGS=""
  for p in com.dts.freefireth com.dts.freefiremax $EXTRA_PKGS; do
    [[ "$PKGS" == *" $p "* ]] || continue
    [[ " $GAME_PKGS " == *" $p "* ]] && continue
    GAME_PKGS="$GAME_PKGS $p"
  done
  GAME_PKGS="${GAME_PKGS# }"
}

pkg_label() {
  case "$1" in
    com.dts.freefireth)  echo "Free Fire" ;;
    com.dts.freefiremax) echo "Free Fire MAX" ;;
    *) echo "$1" ;;
  esac
}

show_status() {
  local p g=""
  for p in $GAME_PKGS; do g="$g$(pkg_label "$p"), "; done
  printf '\n  %s%s%s · Android %s (SDK %s)\n' "$WH" "$MODEL" "$RS" "$REL" "$SDK"
  printf '  %sLayar %s %s · %s dpi · %s Hz\n' "$DM" "$RS" "${SIZE_OVR:-$SIZE_PHYS}" "${DPI_OVR:-$DPI_PHYS}" "$HZ_MAX"
  printf '  %sAkses %s %s%s%s (uid %s)\n' "$DM" "$RS" "$GR" "$MODE" "$RS" "$PRIV_UID"
  printf '  %sGame  %s %s\n' "$DM" "$RS" "${g%, }${g:+}"
  [ -z "$g" ] && printf '\033[1A\033[K  %sGame  %s %sbelum terdeteksi%s\n' "$DM" "$RS" "$YL" "$RS"
  [ -n "$LAST_APPLY" ] && printf '  %sTerakhir%s %s\n' "$DM" "$RS" "$LAST_APPLY"
}

# ═══ 7. MODUL TWEAK ═══════════════════════════════════════════════
snap_fps() {  # nilai FPS valid Game Mode yang ≤ Hz layar
  local hz="${1:-60}" f best=30
  for f in 30 45 60 90 120; do [ "$hz" -ge "$f" ] && best=$f; done
  echo "$best"
}

m_touch() {
  sp system pointer_speed 7
  sp system high_touch_sensitivity_enabled 1
  sp secure long_press_timeout 150
  sp secure multi_press_timeout 100
}

m_anim() {
  local k
  for k in window_animation_scale transition_animation_scale animator_duration_scale; do
    sp global "$k" "$ANIM"
  done
  sp global disable_window_blurs 1
}

m_gfx() {
  # Renderer dan cache HWUI dari supersetting.sh. Properti debug bisa
  # diabaikan Android/vendor; kegagalan tidak menghentikan modul lain.
  case "$GFX_RENDERER" in
    skiagl)
      qs "setprop debug.hwui.renderer skiagl"
      qs "setprop debug.renderengine.backend skiaglthreaded"
      ;;
    skiavk)
      qs "setprop debug.hwui.renderer skiavk"
      qs "setprop debug.renderengine.backend skiavkthreaded"
      ;;
    default)
      qs "setprop debug.hwui.renderer ''"
      qs "setprop debug.renderengine.backend ''"
      ;;
  esac
  qs "setprop debug.hwui.disable_scissor_opt false"
  qs "setprop debug.hwui.texture_cache_size 24"
  qs "setprop debug.hwui.layer_cache_size 16"
  qs "setprop debug.hwui.drop_shadow_cache_size 2"
  qs "setprop debug.sf.latch_unsignaled 1"
  qs "setprop debug.sf.disable_backpressure 1"
  qs "setprop debug.sf.hw 1"
  qs "setprop debug.egl.hw 1"
  qs "setprop debug.performance.tuning 1"
  sp global hidden_force_high_end_graphics 1
  if [ -n "$GAME_PKGS" ]; then
    if [ "$SDK" -ge 31 ]; then
      sp global updatable_driver_production_opt_in_apps "${GAME_PKGS// /,}"
    else
      sp global game_driver_opt_in_apps "${GAME_PKGS// /,}"
    fi
  fi
}

m_hz() {
  local hz="$HZ_MAX"
  case "$HZ_MODE" in skip) return 0 ;; manual) hz="$HZ_MANUAL" ;; esac
  sp system peak_refresh_rate "$hz"
  sp system min_refresh_rate "$hz"
  sp system user_refresh_rate "$hz"
}

m_game() {
  local p fps opt cfg
  fps="$GAME_FPS"; [ "$fps" = auto ] && fps=$(snap_fps "$HZ_MAX")
  for p in $GAME_PKGS; do
    if [ "$SDK" -ge 31 ]; then
      opt=""; cfg="mode=2"
      [ "$fps" != none ]           && { opt="$opt --fps $fps"; cfg="$cfg,fps=$fps"; }
      [ "$GAME_DOWNSCALE" != none ] && { opt="$opt --downscale $GAME_DOWNSCALE"; cfg="$cfg,downscaleFactor=$GAME_DOWNSCALE"; }
      qs "cmd game reset $p"
      qs "cmd game set --mode performance$opt $p"
      qs "cmd game mode performance $p"
      qs "device_config put game_overlay $p $cfg"
    fi
    qs "dumpsys deviceidle whitelist +$p"
    qs "am set-standby-bucket $p active"
    qs "cmd appops set $p RUN_IN_BACKGROUND allow"
    qs "cmd appops set $p RUN_ANY_IN_BACKGROUND allow"
    case "$BRAND" in
      xiaomi|redmi|poco) qs "am broadcast -a com.miui.securitycenter.action.GAME_SPEED_UP --es packageName $p" ;;
    esac
  done
}

m_power() {
  qs "cmd power set-fixed-performance-mode-enabled true"
  qs "cmd power set-adaptive-power-saver-enabled false"
  sp global low_power 0
  sp global low_power_trigger_level 0
  sp global automatic_power_save_mode 0
  sp global dynamic_power_savings_enabled 0
  sp global adaptive_battery_management_enabled 0
  case "$BRAND" in
    samsung)           sp system psm_switch 0; sp global sem_enhanced_cpu_responsiveness 1 ;;
    xiaomi|redmi|poco) sp system POWER_SAVE_MODE_OPEN 0; sp global POWER_SAVE_MODE_OPEN 0 ;;
  esac
}

m_thermal() {
  qs "cmd thermalservice override-status 0"
  qs "dumpsys deviceidle disable all"
  sp global app_standby_enabled 0
  sp global forced_app_standby_enabled 0
}

m_mem() {
  local p
  qs "am kill-all"
  qs "device_config set_sync_disabled_for_tests persistent"
  qs "device_config put activity_manager max_phantom_processes 2147483647"
  qs "device_config put activity_manager max_cached_processes $BG_LIMIT"
  sp global settings_enable_monitor_phantom_procs false
  sp global activity_manager_constants "max_cached_processes=$BG_LIMIT"
  for p in $KILL_LIST; do qs "am force-stop $p"; done
}

m_net() {
  qs "cmd wifi force-low-latency-mode enabled"
  qs "cmd wifi force-hi-perf-mode enabled"
  sp global wifi_scan_throttle_enabled 1
  sp global wifi_scan_always_enabled 0
  sp global ble_scan_always_enabled 0
  sp global wifi_networks_available_notification_on 0
  sp global network_recommendations_enabled 0
  case "$DNS_MODE" in
    cloudflare) sp global private_dns_mode hostname; sp global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com ;;
    google)     sp global private_dns_mode hostname; sp global private_dns_specifier dns.google ;;
    adguard)    sp global private_dns_mode hostname; sp global private_dns_specifier dns.adguard-dns.com ;;
    quad9)      sp global private_dns_mode hostname; sp global private_dns_specifier dns.quad9.net ;;
    off)        sp global private_dns_mode off ;;
    auto)       sp global private_dns_mode opportunistic ;;
  esac
}

m_clean() {
  local p
  for p in $GAME_PKGS; do
    qs "rm -rf /sdcard/Android/data/$p/cache/*"
    qs "rm -f /sdcard/Android/data/$p/files/ffrtc_log.txt /sdcard/Android/data/$p/files/ffrtc_log_bak.txt"
  done
  qs "pm trim-caches 999G"
  qs "logcat -b all -c"
  qs "sm fstrim"
  qs "sync"
}

m_disp() {
  sp system screen_brightness_mode 0
  # Simpan keadaan NFC sebelum menonaktifkannya agar reset bisa memulihkan.
  q 'nfc_state=$(dumpsys nfc 2>/dev/null | grep -m1 -o "mState=[A-Za-z_]*" | sed "s/mState=//"); [ -n "$nfc_state" ] && bkn nfc "$nfc_state"'
  qs "svc nfc disable"
}

m_root() {
  q 'for g in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor; do echo performance > "$g" 2>/dev/null; done'
  q 'for r in /sys/block/*/queue/read_ahead_kb; do echo 1024 > "$r" 2>/dev/null; done'
  q 'for s in /sys/block/*/queue/iostats; do echo 0 > "$s" 2>/dev/null; done'
  q 'for f in force_clk_on force_bus_on force_rail_on; do echo 1 > /sys/class/kgsl/kgsl-3d0/$f 2>/dev/null; done'
  q 'sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null'
}

# Compile AOT game (lama → spinner)
run_aot() {
  local p t
  for p in $GAME_PKGS; do
    t="Compile $(pkg_label "$p") ($AOT_MODE)"
    step_head "$t"
    ( SX_TO=900 sx "cmd package compile -m $AOT_MODE -f --secondary-dex $p" >/dev/null 2>&1 ) &
    spin_wait $! "$t"
    step_ok "$t"
  done
  STEP_I=$((STEP_I-1))   # step_head sudah menambah per paket; samakan hitungan modul
}

# ═══ 8. BLOAT ═════════════════════════════════════════════════════
BLOAT_SH='
ALL=$(pm list packages 2>/dev/null); EN=$(pm list packages -e 2>/dev/null)
for p in $LIST; do
  echo "$ALL" | grep -q "^package:$p\$" || continue
  isen=0; echo "$EN" | grep -q "^package:$p\$" && isen=1
  case "$ACT" in
    stop)    [ $isen = 1 ] && { am force-stop "$p" >/dev/null 2>&1; echo "R|$p"; } ;;
    disable) [ $isen = 1 ] && { pm disable-user --user 0 "$p" >/dev/null 2>&1 && echo "R|$p"; } ;;
    enable)  [ $isen = 0 ] && { pm enable --user 0 "$p" >/dev/null 2>&1 && echo "R|$p"; } ;;
  esac
done
'

bloat_run() {  # bloat_run stop|disable|enable [quiet]
  local act="$1" out n=0 line
  out=$(SX_TO=120 sx "LIST='$(printf '%s ' $BLOAT_LIST)'; ACT='$act'; $BLOAT_SH" 2>/dev/null)
  while IFS= read -r line; do
    case "$line" in R\|*) n=$((n+1)); [ "$2" = quiet ] || dim "· ${line#R|}" ;; esac
  done <<< "$out"
  case "$act" in
    stop)    ok "$n app dihentikan" ;;
    disable) ok "$n app di-disable" ;;
    enable)  ok "$n app diaktifkan lagi" ;;
  esac
}

step_bloat() {
  local t="Stop app pengganggu"
  step_head "$t"; bloat_run stop quiet >/dev/null; step_ok "$t"
}

bloat_menu() {
  local c
  while :; do
    banner_small; hdr "BLOAT & THROTTLER"
    printf '  %s[1]%s Stop sementara  %s(force-stop)%s\n' "$WH" "$RS" "$DM" "$RS"
    printf '  %s[2]%s Disable         %s(pm disable-user)%s\n' "$WH" "$RS" "$DM" "$RS"
    printf '  %s[3]%s Enable lagi\n' "$WH" "$RS"
    printf '  %s[0]%s Kembali\n\n' "$WH" "$RS"
    c=$(ask "pilih ›") || return
    case "$c" in
      1) echo; bloat_run stop; pause ;;
      2) echo; bloat_run disable; pause ;;
      3) echo; bloat_run enable; pause ;;
      0|"") return ;;
    esac
  done
}

# ═══ 9. RESOLUSI & DPI ════════════════════════════════════════════
calc_scaled() {  # calc_scaled persen → NW NH ND (ukuran genap, dpi ikut diskala)
  local p="$1"
  NW=$(( (PW * p / 100 + 1) / 2 * 2 ))
  NH=$(( (PH * p / 100 + 1) / 2 * 2 ))
  ND=0; [ "$PD" -gt 0 ] && ND=$(( (PD * p + 50) / 100 ))
}

keep_prompt() {  # true = simpan, false = timeout (balik otomatis)
  local s="$1" i k rc
  printf '\n  %sTekan ENTER buat SIMPAN%s — kalau tidak, auto-balik\n' "$YL" "$RS"
  for ((i=s; i>0; i--)); do
    printf '\r  %sbalik dalam %2ds…%s ' "$DM" "$i" "$RS"
    read -r -t 1 -n 1 k; rc=$?
    [ $rc -le 128 ] && { printf '\n'; return 0; }
  done
  printf '\n'; return 1
}

apply_display() {  # apply_display "WxH" "dpi"   (salah satu boleh kosong)
  local ns="$1" nd="$2" ps="$SIZE_OVR" pd="$DPI_OVR" cmd="" rv=""
  [ -n "$ns" ] && cmd="wm size $ns;"
  [ -n "$nd" ] && [ "$nd" != 0 ] && cmd="$cmd wm density $nd;"
  sx "$cmd" >/dev/null 2>&1
  ok "Diterapkan: ${ns:-ukuran tetap} · ${nd:+$nd dpi}"
  if [ "$CONFIRM_SECS" -gt 0 ] && [ "$NONINT" != 1 ]; then
    if keep_prompt "$CONFIRM_SECS"; then
      ok "Disimpan"
    else
      [ -n "$ns" ] && rv="wm size ${ps:-reset};"
      [ -n "$nd" ] && [ "$nd" != 0 ] && rv="$rv wm density ${pd:-reset};"
      sx "$rv" >/dev/null 2>&1
      wrn "Tidak dikonfirmasi → dikembalikan"
    fi
  fi
}

reso_cli() {
  read_display
  if [ "$REASO" = reset ]; then
    sx "wm size reset; wm density reset" >/dev/null 2>&1; ok "Resolusi & DPI direset"; return 0
  fi
  [[ "$SIZE_PHYS" =~ ^[0-9]+x[0-9]+$ ]] || { bad "Gagal baca resolusi fisik"; return 1; }
  PW=${SIZE_PHYS%x*}; PH=${SIZE_PHYS#*x}; PD=${DPI_PHYS:-0}
  [[ "$PD" =~ ^[0-9]+$ ]] || PD=0
  calc_scaled "$REASO"
  apply_display "${NW}x${NH}" "$ND"
}

reso_menu() {
  local c v p opts
  while :; do
    read_display
    banner_small; hdr "RESOLUSI & DPI"
    if ! [[ "$SIZE_PHYS" =~ ^[0-9]+x[0-9]+$ ]]; then bad "Gagal baca resolusi layar"; pause; return; fi
    PW=${SIZE_PHYS%x*}; PH=${SIZE_PHYS#*x}; PD=${DPI_PHYS:-0}; [[ "$PD" =~ ^[0-9]+$ ]] || PD=0
    printf '  %sFisik%s %s · %s dpi\n' "$DM" "$RS" "$SIZE_PHYS" "$DPI_PHYS"
    printf '  %sAktif%s %s%s · %s dpi%s %s\n\n' "$DM" "$RS" "$WH" "${SIZE_OVR:-$SIZE_PHYS}" "${DPI_OVR:-$DPI_PHYS}" "$RS" \
      "$([ -n "$SIZE_OVR$DPI_OVR" ] && echo '(diubah)' || echo '(asli)')"
    printf '  %s[1]%s Preset persen %s(95%%…60%%)%s\n' "$WH" "$RS" "$DM" "$RS"
    printf '  %s[2]%s Ukuran custom  %s(WxH)%s\n' "$WH" "$RS" "$DM" "$RS"
    printf '  %s[3]%s DPI custom\n' "$WH" "$RS"
    printf '  %s[4]%s Ukuran + DPI custom\n' "$WH" "$RS"
    printf '  %s[5]%s Downscale per-game %s(layar tetap)%s\n' "$WH" "$RS" "$DM" "$RS"
    printf '  %s[6]%s Kembalikan ke bawaan\n' "$WH" "$RS"
    printf '  %s[0]%s Kembali\n\n' "$WH" "$RS"
    c=$(ask "pilih ›") || return
    case "$c" in
      1)
        opts=()
        for p in 95 90 85 80 75 70 65 60; do
          calc_scaled "$p"; opts+=("${p}%  ${NW}x${NH} · ${ND}dpi")
        done
        v=$(choose "preset ›" "${opts[@]}") || { bad "batal"; pause; continue; }
        p=${v%%\%*}; calc_scaled "$p"
        apply_display "${NW}x${NH}" "$ND"; pause ;;
      2)
        v=$(ask "WxH (mis. 1080x2400) ›") || return
        if [[ "$v" =~ ^[0-9]{3,5}x[0-9]{3,5}$ ]]; then apply_display "$v" ""; else bad "format salah"; fi; pause ;;
      3)
        v=$(ask "DPI (mis. 400) ›") || return
        if [[ "$v" =~ ^[0-9]{2,4}$ ]]; then apply_display "" "$v"; else bad "angka saja"; fi; pause ;;
      4)
        v=$(ask "WxH ›") || return; p=$(ask "DPI ›") || return
        if [[ "$v" =~ ^[0-9]{3,5}x[0-9]{3,5}$ ]] && [[ "$p" =~ ^[0-9]{2,4}$ ]]; then apply_display "$v" "$p"; else bad "format salah"; fi; pause ;;
      5) game_downscale_menu; pause ;;
      6) sx "wm size reset; wm density reset" >/dev/null 2>&1; ok "Resolusi & DPI kembali ke bawaan"; pause ;;
      0|"") return ;;
    esac
  done
}

game_downscale_menu() {
  local v
  [ -z "$GAME_PKGS" ] && { bad "Game belum terdeteksi"; return; }
  [ "$SDK" -ge 31 ]  || { bad "Butuh Android 12+ (SDK 31)"; return; }
  inf "Render game lebih kecil, layar & UI tetap normal"
  v=$(choose "downscale ›" none 0.9 0.8 0.7 0.6 0.5) || { bad "batal"; return; }
  GAME_DOWNSCALE="$v"; save_conf
  BATCH=""; m_game; flush
  ok "Downscale game: $v — restart game-nya"
}

# ═══ 10. PROFIL & ORKESTRASI ══════════════════════════════════════
mod_title() {
  case "$1" in
    touch)   echo "Touch & respons" ;;
    anim)    echo "Animasi & blur" ;;
    gfx)     echo "Grafis & rendering" ;;
    hz)      echo "Refresh rate maksimal" ;;
    game)    echo "Profil game (Game Mode)" ;;
    power)   echo "Mode performa & baterai" ;;
    thermal) echo "Thermal & Doze/Standby off" ;;
    mem)     echo "RAM & proses background" ;;
    net)     echo "Jaringan low-latency" ;;
    clean)   echo "Bersihkan cache & storage" ;;
    aot)     echo "Compile game (AOT speed)" ;;
    disp)    echo "Layar & NFC" ;;
    bloat)   echo "Stop app pengganggu" ;;
    root)    echo "Kernel tweak (butuh root)" ;;
  esac
}

is_on()  { [[ "$ON" == *" $1 "* ]]; }
toggle() { if is_on "$1"; then ON="${ON/ $1 / }"; else ON="${ON}$1 "; fi; }

mod_runnable() {
  is_on "$1" || return 1
  case "$1" in
    root)     [ "$PRIV_UID" = 0 ] || return 1 ;;
    game|aot) [ -n "$GAME_PKGS" ] || return 1 ;;
  esac
  return 0
}

apply_run() {  # apply_run "LABEL"  (pakai $ON)
  local label="$1" m r
  hdr "MENERAPKAN · $label"
  [ "$label" = BRUTAL ] && wrn "Profil maksimal dapat menaikkan konsumsi baterai/panas; Android/vendor bisa mengabaikan sebagian tweak."
  [ -z "$GAME_PKGS" ] && wrn "Game belum terdeteksi — tweak khusus game dilewati"
  STEP_N=0; STEP_I=0
  for m in $ALL_MODS; do mod_runnable "$m" && STEP_N=$((STEP_N+1)); done
  for m in $ALL_MODS; do
    mod_runnable "$m" || continue
    case "$m" in
      aot)   run_aot ;;
      bloat) step_bloat ;;
      *)     step "$(mod_title "$m")" "m_$m" ;;
    esac
  done
  LAST_APPLY="$label · $(date '+%d/%m %H:%M')"; save_conf
  sx "cmd notification post -S bigtext -t 'BLOODYStyle' bloodystyle 'Tweak $label berhasil diterapkan'" >/dev/null 2>&1
  echo
  ok "Selesai. Restart game biar FPS/downscale kebaca."
  if [ "$label" = BRUTAL ] && [ "$NONINT" != 1 ]; then
    echo
    r=$(ask "Ubah resolusi juga? (y/N) ›") || return 0
    [[ "$r" == [yY]* ]] && reso_menu
  fi
}

profile_apply() {
  case "$1" in
    basic)  ON="$PROFILE_BASIC"; apply_run "BASIC" ;;
    max)    ON="$PROFILE_MAX";   apply_run "BRUTAL" ;;
    custom) ON="$CUSTOM_ON";     apply_run "CUSTOM" ;;
  esac
}

custom_menu() {
  local c m i mark
  ON="$CUSTOM_ON"
  while :; do
    banner_small; hdr "CUSTOM — pilih modul"
    i=0
    for m in $ALL_MODS; do
      i=$((i+1))
      if is_on "$m"; then mark="${GR}[x]${RS}"; else mark="${DM}[ ]${RS}"; fi
      printf '  %s%2d%s %s %s' "$WH" "$i" "$RS" "$mark" "$(mod_title "$m")"
      printf '\n'
    done
    printf '\n'
    dim "nomor=on/off · a=semua · n=kosong"
    dim "g=JALANKAN · 0=simpan & kembali"
    c=$(ask "›") || return
    case "$c" in
      0|"")  CUSTOM_ON="$ON"; save_conf; return ;;
      a|A)   ON=" $ALL_MODS " ;;
      n|N)   ON=" " ;;
      g|G)   CUSTOM_ON="$ON"; save_conf; apply_run "CUSTOM"; pause; return ;;
      *[!0-9]*) ;;
      *)     i=0; for m in $ALL_MODS; do i=$((i+1)); [ "$i" = "$c" ] && toggle "$m"; done ;;
    esac
  done
}

# ═══ 11. OPSI ═════════════════════════════════════════════════════
edit_kill_list() {
  local v p
  banner_small; hdr "DAFTAR STOP RAM"
  printf '%s\n' $KILL_LIST | sed 's/^/   · /'
  echo
  dim "tambah: ketik nama paket"
  dim "hapus : -nama.paket  ·  reset  ·  ENTER=selesai"
  while :; do
    v=$(ask "›") || break
    [ -z "$v" ] && break
    case "$v" in
      reset) KILL_LIST="$DEFAULT_KILL"; ok "daftar direset" ;;
      -*)    p=$(san "${v#-}"); KILL_LIST=$(printf '%s\n' $KILL_LIST | grep -vxF "$p" | tr '\n' ' '); KILL_LIST="${KILL_LIST% }"; ok "dihapus: $p" ;;
      *)     p=$(san "$v"); if [ -n "$p" ] && [[ " $KILL_LIST " != *" $p "* ]]; then KILL_LIST="$KILL_LIST $p"; ok "ditambah: $p"; fi ;;
    esac
  done
  save_conf
}

row() { printf '  %s[%s]%s %-17s %s%s%s\n' "$WH" "$1" "$RS" "$2" "$CY" "$3" "$RS"; }

settings_menu() {
  local c v
  while :; do
    banner_small; hdr "OPSI"
    row 1 "Animasi"        "$ANIM"
    row 2 "Renderer UI"    "$GFX_RENDERER"
    row 3 "Refresh rate"   "$HZ_MODE$([ "$HZ_MODE" = manual ] && echo " ${HZ_MANUAL}Hz")"
    row 4 "FPS game"       "$GAME_FPS"
    row 5 "Downscale game" "$GAME_DOWNSCALE"
    row 6 "Private DNS"    "$DNS_MODE"
    row 7 "Batas proses"   "$BG_LIMIT"
    row 8 "Timer konfirmasi" "${CONFIRM_SECS}s"
    row 9 "Game tambahan"  "${EXTRA_PKGS:-—}"
    row A "Daftar stop RAM" "$(printf '%s\n' $KILL_LIST | wc -l | tr -d ' ') app"
    row B "Mode kompilasi ART" "$AOT_MODE"
    printf '  %s[0]%s Kembali\n\n' "$WH" "$RS"
    c=$(ask "pilih ›") || return
    case "$c" in
      1) v=$(choose "animasi ›" 0 0.1 0.2 0.3 0.5 1) && ANIM="$v" ;;
      2) v=$(choose "renderer ›" skiagl skiavk default) && GFX_RENDERER="$v" ;;
      3) v=$(choose "refresh ›" auto manual skip) && HZ_MODE="$v"
         if [ "$HZ_MODE" = manual ]; then
           v=$(ask "Hz (mis. 90/120/144) ›" "$HZ_MANUAL") || return
           [[ "$v" =~ ^[0-9]{2,3}$ ]] && HZ_MANUAL="$v"
         fi ;;
      4) v=$(choose "fps ›" auto none 30 45 60 90 120) && GAME_FPS="$v" ;;
      5) v=$(choose "downscale ›" none 0.9 0.8 0.7 0.6 0.5) && GAME_DOWNSCALE="$v" ;;
      6) v=$(choose "dns ›" keep auto off cloudflare google adguard quad9) && DNS_MODE="$v" ;;
      7) v=$(choose "batas ›" 4 6 8 12 16 32) && BG_LIMIT="$v" ;;
      8) v=$(choose "detik ›" 0 10 15 30) && CONFIRM_SECS="$v" ;;
      9) v=$(ask "paket (spasi, kosong=hapus) ›") || return
         EXTRA_PKGS=$(san "$v")
         # Hanya nama paket sederhana, hindari karakter shell yang tak diinginkan.
         EXTRA_PKGS=$(printf '%s\n' "$EXTRA_PKGS" | tr ' ' '\n' | grep -E '^[A-Za-z0-9_]+([.][A-Za-z0-9_]+)+$' | tr '\n' ' ')
         EXTRA_PKGS="${EXTRA_PKGS% }"
         detect_games ;;
      a|A) edit_kill_list ;;
      b|B) v=$(choose "mode ART ›" speed speed-profile everything-profile) && AOT_MODE="$v" ;;
      0|"") save_conf; return ;;
    esac
    save_conf
  done
}

# ═══ 12. RESET ════════════════════════════════════════════════════
do_reset() {
  local p k v ns key line src allp
  hdr "RESET SEMUA"
  allp="com.dts.freefireth com.dts.freefiremax $GAME_PKGS $EXTRA_PKGS"
  STEP_N=5; STEP_I=0

  # 1. setelan sistem (dari backup, atau nilai bawaan)
  BATCH=""
  if [ -s "$BACKUP" ]; then src=$(cat "$BACKUP"); else src="$FALLBACK"; fi
  while IFS= read -r line; do
    case "$line" in ''|meta:*) continue ;; esac
    k="${line%%=*}"; v="${line#*=}"; ns="${k%%:*}"; key="${k#*:}"
    [ -z "$ns" ] || [ -z "$key" ] && continue
    if [ "$v" = null ] || [ -z "$v" ]; then q "settings delete $ns $key >/dev/null 2>&1"
    else q "settings put $ns $key $(printf '%q' "$v") >/dev/null 2>&1"; fi
  done <<< "$src"
  step_head "Setelan sistem"; flush; step_ok "Setelan sistem"

  # 2. game & performa
  BATCH=""
  for p in $allp; do
    qs "cmd game reset $p"
    qs "device_config delete game_overlay $p"
    qs "dumpsys deviceidle whitelist -$p"
    qs "am set-standby-bucket $p working_set"
    qs "cmd appops set $p RUN_IN_BACKGROUND default"
    qs "cmd appops set $p RUN_ANY_IN_BACKGROUND default"
    qs "cmd package compile --reset $p"
  done
  qs "cmd power set-fixed-performance-mode-enabled false"
  qs "cmd power set-adaptive-power-saver-enabled true"
  qs "cmd thermalservice reset"
  qs "dumpsys deviceidle enable all"
  step_head "Game & performa"; flush; step_ok "Game & performa"

  # 3. grafis, memori, jaringan
  BATCH=""
  for k in debug.hwui.renderer debug.renderengine.backend debug.hwui.disable_scissor_opt debug.hwui.texture_cache_size debug.hwui.layer_cache_size debug.hwui.drop_shadow_cache_size debug.sf.latch_unsignaled debug.sf.disable_backpressure debug.sf.hw debug.egl.hw debug.performance.tuning; do
    qs "setprop $k ''"
  done
  qs "device_config delete activity_manager max_phantom_processes"
  qs "device_config delete activity_manager max_cached_processes"
  qs "device_config set_sync_disabled_for_tests none"
  qs "cmd wifi force-low-latency-mode disabled"
  qs "cmd wifi force-hi-perf-mode disabled"
  step_head "Grafis, memori, jaringan"; flush; step_ok "Grafis, memori, jaringan"

  # 4. layar & NFC
  BATCH=""
  qs "wm size reset"
  qs "wm density reset"
  if grep -Eq '^meta:nfc=(on|enabled|STATE_ON|ON)$' "$BACKUP" 2>/dev/null; then
    qs "svc nfc enable"
  elif grep -Eq '^meta:nfc=(off|disabled|STATE_OFF|OFF)$' "$BACKUP" 2>/dev/null; then
    qs "svc nfc disable"
  fi
  step_head "Resolusi, DPI, NFC"; flush; step_ok "Resolusi, DPI, NFC"

  # 5. kernel (root) + app yang pernah di-disable
  BATCH=""
  if [ "$PRIV_UID" = 0 ]; then
    q 'for p in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do av=$(cat $p/scaling_available_governors 2>/dev/null); for g in schedutil walt sched interactive ondemand; do case " $av " in *" $g "*) echo $g > $p/scaling_governor 2>/dev/null; break;; esac; done; done'
    q 'for r in /sys/block/*/queue/read_ahead_kb; do echo 128 > "$r" 2>/dev/null; done'
    q 'for s in /sys/block/*/queue/iostats; do echo 1 > "$s" 2>/dev/null; done'
    q 'for f in force_clk_on force_bus_on force_rail_on; do echo 0 > /sys/class/kgsl/kgsl-3d0/$f 2>/dev/null; done'
  fi
  step_head "Kernel & app yang di-disable"; flush
  bloat_run enable quiet >/dev/null
  step_ok "Kernel & app yang di-disable"

  rm -f "$BACKUP"; LAST_APPLY=""; save_conf
  echo
  ok "Semua dikembalikan. Restart HP disarankan."
}

# ═══ 13. INFO ═════════════════════════════════════════════════════
info_screen() {
  hdr "INFO"
  show_status
  echo
  dim "akses  : $MODE ${RISH_BIN:+($RISH_BIN)}"
  dim "backup : $([ -s "$BACKUP" ] && echo "ada ($(wc -l < "$BACKUP" | tr -d ' ') entri)" || echo "belum ada")"
  dim "config : $CONF"
  [ "$VULKAN" -gt 0 ] && dim "vulkan : didukung" || dim "vulkan : tidak terdeteksi"
  [ "$PRIV_UID" = 0 ] && dim "root   : aktif (modul kernel tersedia)"
}

# ═══ 14. MENU UTAMA & CLI ═════════════════════════════════════════
main_menu() {
  local c
  while :; do
    banner; show_status; echo
    printf '  %s[1]%s BASIC    %s· ringan, tanpa ubah layar%s\n' "$WH" "$RS" "$DM" "$RS"
    printf '  %s[2]%s BRUTAL   %s· semua tweak maksimal%s\n'    "$WH" "$RS" "$DM" "$RS"
    printf '  %s[3]%s CUSTOM   %s· pilih modul sendiri%s\n'     "$WH" "$RS" "$DM" "$RS"
    printf '  %s[4]%s Resolusi %s· ubah / downscale / reset%s\n' "$WH" "$RS" "$DM" "$RS"
    printf '  %s[5]%s Bloat    %s· stop / disable / enable%s\n'  "$WH" "$RS" "$DM" "$RS"
    printf '  %s[6]%s Opsi     %s· animasi, FPS, DNS, dll%s\n'   "$WH" "$RS" "$DM" "$RS"
    printf '  %s[7]%s Reset    %s· balik ke setelan awal%s\n'    "$WH" "$RS" "$DM" "$RS"
    printf '  %s[8]%s Info     %s· status & setup rish (s)%s\n'  "$WH" "$RS" "$DM" "$RS"
    printf '  %s[0]%s Keluar\n\n' "$WH" "$RS"
    c=$(ask "pilih ›") || exit 0
    case "$c" in
      1) profile_apply basic;  pause ;;
      2) profile_apply max;    pause ;;
      3) custom_menu ;;
      4) reso_menu ;;
      5) bloat_menu ;;
      6) settings_menu ;;
      7) do_reset; pause ;;
      8) info_screen; pause ;;
      s|S) setup_rish && probe_priv && ok "Akses: $MODE"; pause ;;
      0|q|Q) printf '\n  %sSampai jumpa.%s\n\n' "$DM" "$RS"; exit 0 ;;
    esac
  done
}

usage() {
  cat <<EOF
BLOODYStyle v$VER — Termux + Shizuku

  bash BLOODYStyle.sh              menu interaktif
  bash BLOODYStyle.sh --basic      profil BASIC (tanpa ubah layar)
  bash BLOODYStyle.sh --max        profil BRUTAL (semua tweak)
  bash BLOODYStyle.sh --custom     pakai modul pilihan terakhir
  bash BLOODYStyle.sh --reset      kembalikan semuanya
  bash BLOODYStyle.sh --info       status perangkat & akses

  tambahan:  --reso 90 | --reso reset   (skala resolusi, tanpa konfirmasi)
             --debug   (tampilkan perintah & error)    --no-color
EOF
}

parse_args() {
  while [ $# -gt 0 ]; do
    case "$1" in
      --basic)        ACTION=basic ;;
      --max|--brutal) ACTION=max ;;
      --custom)       ACTION=custom ;;
      --reset)        ACTION=reset ;;
      --info)         ACTION=info ;;
      --check)
        if bash -n "${BASH_SOURCE[0]}"; then
          printf 'BLOODYStyle v%s: sintaks Bash valid.\n' "$VER"
          exit 0
        else
          exit 2
        fi
        ;;
      --version)      printf 'BLOODYStyle v%s\n' "$VER"; exit 0 ;;
      --reso)         REASO="${2:-}"; shift ;;
      --debug)        DEBUG=1 ;;
      --no-color)     NO_COLOR=1 ;;
      -h|--help)      usage; exit 0 ;;
      *)              echo "Opsi tidak dikenal: $1"; usage; exit 1 ;;
    esac
    shift
  done
  if [ -n "$REASO" ]; then
    if [ "$REASO" != reset ] && ! { [[ "$REASO" =~ ^[0-9]+$ ]] && [ "$REASO" -ge 40 ] && [ "$REASO" -le 100 ]; }; then
      echo "--reso butuh angka 40-100 atau 'reset'"; exit 1
    fi
    [ "$ACTION" = menu ] && ACTION=reso
  fi
  [ "$ACTION" != menu ] && NONINT=1
  return 0
}

main() {
  local c
  parse_args "$@"
  setup_colors
  load_conf
  [ "$NONINT" = 1 ] || banner
  inf "Cek akses Shizuku…"
  if ! probe_priv; then
    shizuku_help
    [ "$NONINT" = 1 ] && exit 1
    echo
    c=$(ask "Setup rish otomatis sekarang? (y/N) ›") || exit 1
    if [[ "$c" == [yY]* ]]; then
      setup_rish && probe_priv || { bad "Masih belum siap."; exit 1; }
    else
      exit 1
    fi
  fi
  ok "Akses OK: $MODE (uid $PRIV_UID)"
  gather_info; detect_games

  case "$ACTION" in
    menu)   main_menu ;;
    basic)  profile_apply basic ;;
    max)    profile_apply max ;;
    custom) profile_apply custom ;;
    reset)  do_reset ;;
    info)   info_screen ;;
    reso)   ;;
  esac
  [ -n "$REASO" ] && reso_cli
  return 0
}

main "$@"
